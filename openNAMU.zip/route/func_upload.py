from .tool.func import *

def func_upload_2(conn, app_var):
    curs = conn.cursor()

    if acl_check(None, 'upload') == 1:
        return re_error('/ban')

    if flask.request.method == 'POST':
        if captcha_post(flask.request.form.get('g-recaptcha-response', flask.request.form.get('g-recaptcha', ''))) == 1:
            return re_error('/error/13')
        else:
            captcha_post('', 0)

        file_data = flask.request.files.getlist("f_data[]", None)
        if not file_data:
            return re_error('/error/9')

        file_len = len(file_data)

        if int(wiki_set(3)) * 1024 * 1024 * file_len < flask.request.content_length:
            return re_error('/error/17')

        if file_len == 1:    
            file_num = None
        else:
            if acl_check(None, 'many_upload') == 1:
                return re_error('/ban')

            file_num = 1

        for data in file_data:
            value = os.path.splitext(data.filename)[1]
            
            curs.execute(db_change("select html from html_filter where kind = 'extension'"))
            extension = [i[0].lower() for i in curs.fetchall()]
            if not re.sub(r'^\.', '', value).lower() in extension:
                return re_error('/error/14')

            if flask.request.form.get('f_name', None):
                name = flask.request.form.get('f_name', None) + (' ' + str(file_num) if file_num else '') + value
            else:
                name = data.filename

            piece = os.path.splitext(name)
            if re.search(r'[^ㄱ-힣0-9a-zA-Z_\- ]', piece[0]):
                return re_error('/error/22')

            e_data = sha224_replace(piece[0]) + piece[1]

            curs.execute(db_change("select title from data where title = ?"), ['file:' + name])
            if curs.fetchall():
                return re_error('/error/16')

            curs.execute(db_change("select html from html_filter where kind = 'file'"))
            db_data = curs.fetchall()
            for i in db_data:
                t_re = re.compile(i[0])
                if t_re.search(name):
                    return redirect('/file_filter')

            if os.path.exists(os.path.join(app_var['path_data_image'], e_data)):
                os.remove(os.path.join(app_var['path_data_image'], e_data))
                data.save(os.path.join(app_var['path_data_image'], e_data))
            else:
                data.save(os.path.join(app_var['path_data_image'], e_data))

            ip = ip_check()
            g_lice = flask.request.form.get('f_lice', '')
            file_size = os.stat(os.path.join(app_var['path_data_image'], e_data)).st_size

            curs.execute(db_change("select data from other where name = 'markup'"))
            db_data = curs.fetchall()
            if db_data and db_data[0][0] == 'namumark':
                file_d = '' + \
                    '[[file:' + name + ']]\n' + \
                    '{{{[[file:' + name + ']]}}}\n\n' + \
                    (g_lice + '\n' if g_lice != '' else '') + \
                    flask.request.form.get('f_lice_sel', 'direct_input') + '\n' + \
                    (ip if ip_or_user(ip) != 0 else '[[user:' + ip + ']]') + '\n' + \
                    str(file_size) + ' Byte\n' + \
                    '[[category:' + re.sub(r'\]', '_', flask.request.form.get('f_lice_sel', '')) + ']]' + \
                ''
            else:
                file_d = '' + \
                    '/image/' + e_data + '\n\n' + \
                    (g_lice + '\n' if g_lice != '' else '') + \
                    flask.request.form.get('f_lice_sel', 'direct_input') + '\n' + \
                    ip + \
                    str(file_size) + ' Byte\n' + \
                ''

            curs.execute(db_change("insert into data (title, data) values (?, ?)"), ['file:' + name, file_d])
            curs.execute(db_change("insert into acl (title, decu, dis, why, view) values (?, 'admin', '', '', '')"), ['file:' + name])

            render_set(
                title = 'file:' + name,
                data = file_d,
                num = 1
            )

            history_plus(
                'file:' + name,
                file_d,
                get_time(),
                ip,
                ip,
                '0',
                'upload'
            )

            if file_num:
                file_num += 1

        conn.commit()

        return redirect('/w/file:' + name)
    else:
        license_list = '''
            <option value="direct_input">''' + load_lang('direct_input') + '''</option>
        '''

        curs.execute(db_change("select html from html_filter where kind = 'image_license'"))
        db_data = curs.fetchall()
        for i in db_data:
            license_list += '''
                <option value="''' + i[0] + '''">''' + i[0] + '''</option>
            '''

        return easy_minify(flask.render_template(skin_check(),
            imp = [load_lang('upload'), wiki_set(), custom(), other2([0, 0])],
            data = '''
                <a href="/file_filter">(''' + load_lang('file_filter_list') + ''')</a>
                <hr class=\"main_hr\">
                ''' + load_lang('max_file_size') + ''' : ''' + wiki_set(3) + '''MB
                <hr class=\"main_hr\">
                <form method="post" enctype="multipart/form-data" accept-charset="utf8">
                    <input multiple="multiple" type="file" name="f_data[]">
                    <hr class=\"main_hr\">
                    <input placeholder="''' + load_lang('file_name') + '''" name="f_name" value="''' + flask.request.args.get('name', '') + '''">
                    <hr class=\"main_hr\">
                    <select name="f_lice_sel">
                        ''' + license_list + '''
                    </select>
                    <hr class=\"main_hr\">
                    <textarea rows="10" placeholder="''' + load_lang('other') + '''" name="f_lice"></textarea>
                    <hr class=\"main_hr\">
                    ''' + captcha_get() + '''
                    <button id="save" type="submit">''' + load_lang('save') + '''</button>
                </form>
            ''',
            menu = [['other', load_lang('return')]]
        ))  